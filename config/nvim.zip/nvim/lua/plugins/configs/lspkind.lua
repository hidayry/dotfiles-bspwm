return function(_, opts) require("lspkind").init(opts) end
