Fixes Issue # (If it doesn't fix an issue then delete this line)

Description:
Describe the refactor or cleanup that was completed

Other:
Anything else relevant goes here
